/*
 * Copyright 2005-2006 University of Illinois Board of Trustees
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.globus.tomcat.coyote.valves;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.Response;
import org.apache.catalina.valves.ValveBase;

import org.globus.security.gridmap.GridMap;
import org.globus.axis.gsi.GSIConstants;

/**
 * Implementation of a Valve that allows and denies connections based on
 * the local gridmap file. This Valve is designed to work in conjunction
 * with org.globus.tomcat.coyote.net.HTTPSConnector and
 * org.globus.tomcat.coyote.valves.HTTPSValve55. It will not function 
 * unless invoked after HTTPSValve55.
 * <p>
 * The gridmap file can be specified by setting the 
 * <code>gridmapfile</code> property. If unset, standard Globus logic 
 * will be applied to find the file.
 * <p>
 * If the <code>allowUnsecured</code> property is set to 
 * <code>true</code>, then in cases where the HTTPSConnector valve has
 * not set the DN (either it never ran or it's not an SSL connection)
 * the connection will still be allowed. If set to <code>false</code>
 * (the default), connections will be denied if the DN cannot be found.
 * <p>
 * If the <code>meaningfulErrors</code> property is set to               
 * <code>true</code>, then meaningful 403 errors will be sent.           
 * Otherwise, the default access denied message will be sent.
 *
 * @author Kevin J. Price
 */
public class GridmapFilterValve55
    extends ValveBase {

    // ---------------------------------------------------------- Constructors

    /**
     * Class constructor. Determine the <code>gridmapfile</code> if
     * unspecified.
     */
    public GridmapFilterValve55() {
        setGridmapfile(GridMap.getDefaultGridMapLocation());
    }

    // ------------------------------------------------------- Class Variables

    /**
     * The descriptive information related to this implementation.
     */
    private static final String info =
        "org.globus.tomcat.coyote.valves.GridMapFilterValve/1.0";

    // ----------------------------------------------------- Instance Variables 

    private String gridmapfile = null;
    private boolean allowUnsecured = false;
    private boolean meaningfulErrors = false;
    private boolean passRequest = false;

    private GridMap gridmap = null;

    // ------------------------------------------------------------- Properties


    /**
     * Return descriptive information about this Valve implementation.
     */
    public String getInfo() {
        return (info);
    }

    /**
     * Return the <code>gridmapfile</code>
     */
    public String getGridmapfile()
    {
        return (this.gridmapfile);
    }

    /**
     * Set the <code>gridmapfile</code> explicitly
     *
     * @param gridmapfile The full path to the gridmap file
     */
    public void setGridmapfile(String gridmapfile)
    {
        this.gridmapfile = gridmapfile;

        this.gridmap = new GridMap();
        try
        {
          this.gridmap.load(gridmapfile);
        } 
        catch(Exception e)
        {
          this.gridmap = null;
        }
    }

    /**
     * Return whether or not we're allowing unsecured connections
     */
    public boolean getAllowUnsecured()
    {
        return (this.allowUnsecured);
    }

    /**
     * Set whether or not to allow unsecure connections
     *
     * @param allowUnsecured If true, allow unsecured connections
     */
    public void setAllowUnsecured(boolean allowUnsecured)
    {
        this.allowUnsecured = allowUnsecured;
    }

    /**
     * Return whether or not we're sending meaningful error messages
     */
    public boolean getMeaningfulErrors()
    {
        return (this.meaningfulErrors);
    }

    /**
     * Set whether or not we're sending meaningful error messages
     *
     * @param meaningfulErrors If true, send meaningful errors
     */
    public void setMeaningfulErrors(boolean meaningfulErrors)
    {
        this.meaningfulErrors = meaningfulErrors;
    }

    /**
     * Return whether or not we're passing the request down the pipeline 
     * after denying it
     */
    public boolean getPassRequest()
    {
        return (this.passRequest);
    }

    /**
     * Set whether or not we're passing denied requests down the pipeline
     *
     * @param passRequest If true, pass denied requests
     */
    public void setPassRequest(boolean passRequest)
    {
        this.passRequest = passRequest;
    }

    // -------------------------------------------------------- Private Methods

    private void sendError(Response response, String msg)
        throws IOException {
        if (meaningfulErrors)
        {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, msg);
        }
        else
        {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
        }
    }

    // --------------------------------------------------------- Public Methods


    /**
     * Check to see if the request's DN is present in the gridmap file.
     * Allow or deny access appropriately.
     *
     * @param request The servlet request to be processed
     * @param response The servlet response to be created
     *
     * @exception IOException if an input/output error occurs
     * @exception ServletException if a servlet error occurs
     */
    public void invoke(Request request, Response response)
        throws IOException, ServletException {

        if (this.gridmap == null)
        {
            sendError(response, 
                      "grid-mapfile was not found or could not be accessed");
            if (passRequest) 
            {
                getNext().invoke(request, response);
            }
            return;
        } else {
            this.gridmap.refresh();
        }

        String globusID = (String)
          request.getRequest().getAttribute(GSIConstants.GSI_USER_DN);

        if (globusID == null)
        {
            if (!allowUnsecured) 
            {
                sendError(response, 
                          "Insecure authentication method - no DN was provided");
            }
            if (passRequest)
            {
                getNext().invoke(request, response);
            }
            return;
        }

        String userID = gridmap.getUserID(globusID);
        if (userID == null)
        {
            sendError(response, 
                      "DN provided not found in grid-mapfile.");
            if (passRequest)
            {
                getNext().invoke(request, response);
            }
            return;
        }

        request.getRequest().setAttribute(GSIConstants.GSI_AUTH_USERNAME, 
                                          userID);
        
        getNext().invoke(request, response);
    }
    
}
