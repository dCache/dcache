/*
 * Copyright 1999-2006 University of Chicago
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.globus.tomcat.catalina.valves;

import java.net.Socket;
import java.io.IOException;

import javax.servlet.ServletException;

import org.apache.catalina.Request;
import org.apache.catalina.Response;
import org.apache.catalina.ValveContext;
import org.apache.catalina.valves.ValveBase;

import org.ietf.jgss.GSSContext;

import org.globus.tomcat.catalina.net.HTTPSSocket;
import org.globus.axis.gsi.GSIConstants;

public final class HTTPSValve extends ValveBase
{

    // ----------------------------------------------------- Instance Variables

    /**
     * The descriptive information related to this implementation.
     */
    protected static final String info =
        "org.globus.tomcat.catalina.valves.HTTPSTransportValve/1.0";

    // ------------------------------------------------------------- Properties

    /**
     * Return descriptive information about this Valve implementation.
     */
    public String getInfo()
    {
        return (info);
    }

    // --------------------------------------------------------- Public Methods

    /**
     * Expose the security settings associated with this request
     *
     * @param request  The servlet request to be processed
     * @param response The servlet response to be created
     * @param context  The valve context used to invoke the next valve in the
     *                 current processing pipeline
     * @throws IOException      if an input/output error occurs
     * @throws ServletException if a servlet error occurs
     */
    public void invoke(Request request, 
                       Response response,
                       ValveContext context)
        throws IOException, ServletException
    {
        // Expose the security parameters
        expose(request);

        // Invoke the next Valve in our Pipeline
        context.invokeNext(request, response);
    }

    // ------------------------------------------------------ Protected Methods

    /**
     * Expose the certificate chain for this request, if there is one.
     *
     * @param request The Request being processed
     */
    protected void expose(Request request)
    {
        Socket s = request.getSocket();

        if (s == null) 
        {
            return;
        }

        if (!(s instanceof HTTPSSocket))
        {
            return;
        }

        HTTPSSocket socket = (HTTPSSocket) s;

        String globusID = socket.getUserDN();
        if (globusID != null) {
            request.getRequest().setAttribute(GSIConstants.GSI_USER_DN,
                                              globusID);
        }

        GSSContext context = socket.getContext();
        request.getRequest().setAttribute(GSIConstants.GSI_CONTEXT, 
                                          context);
    }
}
