/*
 * Copyright 1999-2006 University of Chicago
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.globus.tomcat.coyote.valves;

import java.net.Socket;
import java.io.IOException;

import javax.servlet.ServletException;

import org.apache.catalina.Request;
import org.apache.catalina.Response;
import org.apache.catalina.ValveContext;
import org.apache.catalina.valves.ValveBase;

import org.apache.coyote.tomcat5.CoyoteRequest;

import org.ietf.jgss.GSSContext;

import org.globus.tomcat.coyote.net.HTTPSConnector;
import org.globus.tomcat.catalina.net.HTTPSSocket;
import org.globus.axis.gsi.GSIConstants;

import org.apache.coyote.InputBuffer;
import org.apache.coyote.http11.InternalInputBuffer;

public final class HTTPSValve extends ValveBase {

    protected static final String info =
        "org.globus.tomcat.catalina.valves.HTTPSTransportValve/1.0";

    public String getInfo() {
        return (info);
    }

    public void invoke(Request request,
                       Response response,
                       ValveContext context)
        throws IOException, ServletException {
        // Expose the security parameters
        expose(request);
        
        // Invoke the next Valve in our Pipeline
        context.invokeNext(request, response);
    }

    private HTTPSSocket getSocketFromInputStream(CoyoteRequest request) {
        InputBuffer inputBuffer = request.getCoyoteRequest().getInputBuffer();
        if (inputBuffer instanceof InternalInputBuffer) {
            InternalInputBuffer internalInputBuffer = (InternalInputBuffer)inputBuffer;
            if (internalInputBuffer.getInputStream() 
                instanceof HTTPSSocket.SocketGSIGssInputStream) {
                HTTPSSocket.SocketGSIGssInputStream in = 
                    (HTTPSSocket.SocketGSIGssInputStream)internalInputBuffer.getInputStream();
                return in.getSocket();
            }
        }
        return null;
    }

    private HTTPSSocket getSocketFromAttribute(CoyoteRequest request) {
        Socket socket = (Socket) request.getCoyoteRequest().getAttribute("SOCKET");
        return (socket instanceof HTTPSSocket) ? (HTTPSSocket)socket : null;
    }

    protected void expose(Request request) {
        CoyoteRequest req = null;

        // check if it is the right (secure) invocation
        if (request instanceof CoyoteRequest &&
            request.getConnector() instanceof HTTPSConnector) {
            req = (CoyoteRequest)request;
        } else {
            return;
        }
        
        // fix scheme name
        req.getCoyoteRequest().scheme().setString("https");

        HTTPSSocket socket = getSocketFromAttribute(req);
        if (socket == null) {
            // failed to get the socket from attribute try another way
            socket = getSocketFromInputStream(req);
            if (socket == null) {
                // failed to get the second way - just return
                return;
            }
        }
        
        String globusID = socket.getUserDN();
        if (globusID != null) {
            request.getRequest().setAttribute(GSIConstants.GSI_USER_DN,
                                              globusID);
        }
        
        GSSContext context = socket.getContext();
        request.getRequest().setAttribute(GSIConstants.GSI_CONTEXT, 
                                          context);
    }
}
