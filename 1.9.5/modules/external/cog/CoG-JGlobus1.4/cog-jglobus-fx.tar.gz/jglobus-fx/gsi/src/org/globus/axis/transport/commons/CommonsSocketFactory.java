/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.axis.transport.commons;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import org.apache.commons.httpclient.ConnectTimeoutException;
import org.apache.commons.httpclient.params.HttpConnectionParams;
import org.apache.commons.httpclient.protocol.ProtocolSocketFactory;

import org.globus.net.SocketFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CommonsSocketFactory implements ProtocolSocketFactory {
        
    private SocketFactory defaultSocketFactory =
        SocketFactory.getDefault();
    
    public Socket createSocket(String host, 
                               int port, 
                               InetAddress localAddress, 
                               int localPort)
        throws IOException, UnknownHostException {
        throw new IOException("not supported");
    }

    public Socket createSocket(String host, 
                               int port) 
        throws IOException, UnknownHostException {
        throw new IOException("not supported");
    }
    
    public Socket createSocket(String host, 
                               int port, 
                               InetAddress localAddress, 
                               int localPort,
                               HttpConnectionParams params)
        throws IOException, UnknownHostException, ConnectTimeoutException {
        return defaultSocketFactory.createSocket(host, port, 
                                                 localAddress, localPort);
    }
    
}
