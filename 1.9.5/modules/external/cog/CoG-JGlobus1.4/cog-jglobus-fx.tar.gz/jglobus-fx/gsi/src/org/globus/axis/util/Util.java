/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.axis.util;

import org.apache.axis.MessageContext;
import org.apache.axis.client.Call;

import org.globus.axis.transport.GSIHTTPTransport;
import org.globus.axis.transport.HTTPSTransport;
import org.globus.axis.gsi.GSIConstants;

import org.ietf.jgss.GSSCredential;

public class Util {
    
    private static boolean transportRegistered = false;
    
    static {
	registerTransport();
    }

    public static GSSCredential getCredentials(MessageContext msgContext) {
	return (GSSCredential)msgContext.getProperty(GSIConstants.GSI_CREDENTIALS);
    }

    public synchronized static void registerTransport() {
	if (transportRegistered) return;
        reregisterTransport();
	transportRegistered = true;
    }

    public synchronized static void reregisterTransport() {
        Call.initialize();
	Call.addTransportPackage("org.globus.net.protocol");
        Call.setTransportForProtocol("httpg", GSIHTTPTransport.class);
        Call.setTransportForProtocol("https", HTTPSTransport.class);
    }

    public static Object getProperty(MessageContext context, String property) {
        Object val = null;
        val = context.getProperty(property);
        if (val != null) {
            return val;
        }
        Call call = (Call) context.getProperty(MessageContext.CALL);
	if (call == null) {
	    return null;
	}
	return call.getProperty(property);
    }
}
