/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tomcat.catalina.net;

import org.globus.common.ChainedIOException;
import org.globus.gsi.gssapi.net.impl.GSIGssSocket;
import org.globus.gsi.gssapi.net.impl.GSIGssInputStream;
import org.globus.gsi.gssapi.net.GssOutputStream;
import org.ietf.jgss.GSSContext;
import org.ietf.jgss.GSSException;

import java.io.InputStream;
import java.io.IOException;
import java.net.Socket;

public class HTTPSSocket extends GSIGssSocket {

    protected boolean autoFlush;
    protected String userDN;

    private boolean init = false;

    public HTTPSSocket(Socket socket, GSSContext context) {
        super(socket, context);
        setAuthorization(null);
    }

    void setAutoFlush(boolean autoFlush) {
        this.autoFlush = autoFlush;
    }

    public String getUserDN() {
        return this.userDN;
    }

    public synchronized void startHandshake()
        throws IOException {
        super.startHandshake();

        if (init) {
            return;
        }

        GSSContext context = getContext();

        try {
            userDN = context.getSrcName().toString();
        } catch (GSSException e) {
            throw new ChainedIOException("Failed to retreive context properties", e);
        }

        if (this.out != null) {
            ((GssOutputStream)this.out).setAutoFlush(this.autoFlush);
        }

        init = true;
    }

    public void close() throws IOException {
        if (out != null) {
            out.flush();
        }
        super.close();
    }

    public void shutdownOutput() throws IOException {
        if (out != null) {
            out.flush();
        }
        super.shutdownOutput();
    }
    
    protected byte[] readToken()
	throws IOException {
	if (this.in == null) {
	    this.in = new SocketGSIGssInputStream(this.socket.getInputStream(),
                                                  this.context,
                                                  this);
	}
        return super.readToken();
    }

    public static class SocketGSIGssInputStream extends GSIGssInputStream {
        
        private HTTPSSocket socket;
        
        public SocketGSIGssInputStream(InputStream in,
                                       GSSContext context,
                                       HTTPSSocket socket) {
            super(in, context);
            this.socket = socket;
        }
        
        public HTTPSSocket getSocket() {
            return this.socket;
        }
    }
    
}
