/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.apache.coyote.http11;

import org.apache.commons.modeler.Registry;
import org.apache.coyote.Request;
import org.apache.tomcat.util.net.TcpConnection;

public class HTTPSProtocol extends Http11Protocol {

    private HttpsConnectionHandler cHandler;

    public HTTPSProtocol() {
        super();
        this.socketFactoryName = "org.globus.tomcat.catalina.net.HTTPSServerSocketFactory";
        this.cHandler = new HttpsConnectionHandler(this);
    }

    public void init() throws Exception {
        super.init();
        ep.setConnectionHandler(this.cHandler);
    }

    public void start() throws Exception {
        super.start();
        if( this.domain != null ) {
            Registry.getRegistry(null, null).registerComponent
                    ( this.cHandler.global, rgOname, null );
        }
    }

    static class HttpsConnectionHandler extends Http11ConnectionHandler {
        public HttpsConnectionHandler(Http11Protocol proto) {
            super(proto);
        }

        public void processConnection(TcpConnection connection, Object thData[]) {
            Http11Processor  processor=null;
            processor = (Http11Processor)thData[Http11Protocol.THREAD_DATA_PROCESSOR];
            Request request = processor.getRequest();
            request.setAttribute("SOCKET", connection.getSocket());
            super.processConnection(connection, thData);
        }
    }

}
