/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.axis.transport.commons;

import java.net.URL;

import org.apache.axis.MessageContext;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.protocol.Protocol;

import org.globus.gsi.GSIConstants;
import org.globus.axis.transport.GSIHTTPTransport;

import org.apache.axis.components.net.CommonsHTTPClientProperties;
import org.apache.axis.components.net.CommonsHTTPClientPropertiesFactory;

import org.globus.axis.transport.HTTPUtils;

/**
 * Overwrites the Axis sender to use a global connection manager
 */
public class HTTPSSender 
    extends org.apache.axis.transport.http.CommonsHTTPSender {
    
    protected static final String[] PARAMS =
    { 
        GSIHTTPTransport.GSI_AUTHORIZATION,
        GSIHTTPTransport.GSI_ANONYMOUS,
        GSIHTTPTransport.GSI_CREDENTIALS,
        GSIConstants.GSI_TRANSPORT,
        GSIHTTPTransport.TRUSTED_CERTIFICATES
    };
    
    private static CommonsHttpConnectionManager globalConnectionManager;
    private static CommonsHTTPClientProperties globalClientProperties;

    static {
        // install protocol handler
        Protocol protocol = 
            new Protocol("https", new CommonsSSLSocketFactory(), 443);
        Protocol.registerProtocol("https", protocol);

        // initialize connection manager
        globalConnectionManager = new CommonsHttpConnectionManager(PARAMS);
        globalClientProperties = CommonsHTTPClientPropertiesFactory.create();
        CommonsHttpConnectionManager.setStaleCheckingEnabled(
                                              globalConnectionManager);
        CommonsHttpConnectionManager.setConnectionIdleTime(
                                              globalConnectionManager);
    }

    protected void initialize() {
        this.clientProperties = globalClientProperties;
        this.connectionManager = globalConnectionManager;
    }

    protected HostConfiguration getHostConfiguration(HttpClient client, 
                                                     MessageContext context,
                                                     URL targetURL) {
        HostConfiguration config = super.getHostConfiguration(client,
                                                              context,
                                                              targetURL);
        
        // handle disable chunking option
        Boolean prop = 
            (Boolean)context.getProperty(HTTPUtils.DISABLE_CHUNKING);
        if (prop != null) {
            client.getParams().setParameter(HTTPUtils.DISABLE_CHUNKING, prop);
        }

        for (int i=0;i<PARAMS.length;i++) {
            Object value = context.getProperty(PARAMS[i]);
            if (value != null) {
                config.getParams().setParameter(PARAMS[i], value);
            }
        }

        return config;
    }

}
