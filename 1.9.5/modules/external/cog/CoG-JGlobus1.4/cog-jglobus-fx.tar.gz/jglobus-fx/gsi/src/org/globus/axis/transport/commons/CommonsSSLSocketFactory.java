/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.axis.transport.commons;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import org.apache.commons.httpclient.ConnectTimeoutException;
import org.apache.commons.httpclient.params.HttpConnectionParams;
import org.apache.commons.httpclient.protocol.ProtocolSocketFactory;

import org.ietf.jgss.GSSException;
import org.ietf.jgss.GSSCredential;

import org.globus.net.SocketFactory;

import org.globus.gsi.GSIConstants;
import org.globus.gsi.TrustedCertificates;
import org.globus.gsi.gssapi.auth.Authorization;
import org.globus.axis.transport.GSIHTTPTransport;
import org.globus.axis.transport.SSLContextHelper;
import org.globus.common.ChainedIOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CommonsSSLSocketFactory implements ProtocolSocketFactory {
    
    private SocketFactory defaultSocketFactory =
        SocketFactory.getDefault();
    
    public Socket createSocket(String host, 
                               int port, 
                               InetAddress localAddress, 
                               int localPort)
        throws IOException, UnknownHostException {
        throw new IOException("not supported");
    }
    
    public Socket createSocket(String host, 
                               int port) 
        throws IOException, UnknownHostException {
        throw new IOException("not supported");
    }
    
    public Socket createSocket(String host, 
                               int port, 
                               InetAddress localAddress, 
                               int localPort,
                               HttpConnectionParams params)
        throws IOException, UnknownHostException, ConnectTimeoutException {
        SSLContextHelper helper = null;
        Authorization authz = null;
        Boolean anonymous = null;
        GSSCredential cred = null;
        Integer protection = null;
        TrustedCertificates trustedCerts = null;

        if (params != null) {
            authz = (Authorization)params.getParameter(
                                      GSIHTTPTransport.GSI_AUTHORIZATION);

            anonymous = (Boolean)params.getParameter(
                                      GSIHTTPTransport.GSI_ANONYMOUS);

            cred = (GSSCredential)params.getParameter(
                                      GSIHTTPTransport.GSI_CREDENTIALS);

            protection = (Integer)params.getParameter(
                                      GSIConstants.GSI_TRANSPORT);

            trustedCerts = (TrustedCertificates)params
                .getParameter(GSIHTTPTransport.TRUSTED_CERTIFICATES);
        }

        try {
            helper = new SSLContextHelper(host, port,
                                          authz, anonymous, cred, protection,
                                          trustedCerts);
        } catch (GSSException e) {
            throw new ChainedIOException(
                  "Failed to initialize security context", e);
        }

        Socket socket = defaultSocketFactory.createSocket(host, 
                                                          port,
                                                          localAddress,
                                                          localPort);
        return helper.wrapSocket(socket);
    }
    
}
