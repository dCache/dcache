/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.axis.gsi;

public interface GSIConstants extends org.globus.gsi.GSIConstants {

    public static final String
        GSI_CREDENTIALS = "org.globus.gsi.credentials",
        GSI_AUTHORIZATION = "org.globus.gsi.authorization",
        GSI_MODE = "org.globus.gsi.mode",
        GSI_AUTH_USERNAME = "org.globus.gsi.authorized.user.name",
        GSI_USER_DN = "org.globus.gsi.authorized.user.dn",
        GSI_ANONYMOUS = "org.globus.gsi.anonymous",
        GSI_CONTEXT = "org.globus.gsi.context";

    /* this is just a hack for now
     * something more type safe will be
     * much better */
    public static final String
        /* behaves just like a regular ssl socket */
        GSI_MODE_SSL = "ssl",
        /* send no delegation character */
        GSI_MODE_NO_DELEG = "gsi",
        /* performs full delegation */
        GSI_MODE_FULL_DELEG = "gsifull",
        /* performs limited delegation - default */
        GSI_MODE_LIMITED_DELEG = "gsilimited";

}
