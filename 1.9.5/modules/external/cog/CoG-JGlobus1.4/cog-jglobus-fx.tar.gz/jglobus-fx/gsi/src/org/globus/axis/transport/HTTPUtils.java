/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.axis.transport;

import java.util.Hashtable;

import javax.xml.rpc.Stub;

import org.apache.axis.MessageContext;
import org.apache.axis.transport.http.HTTPConstants;

public class HTTPUtils {
    
    public static final String DISABLE_CHUNKING = 
        "transport.http.disableChunking";

    /**
     * Sets connection timeout.
     *
     * @param stub The stub to set the property on
     * @param timeout the new timeout value in milliseconds
     */
    public static void setTimeout(Stub stub, int timeout) {
        if (stub instanceof org.apache.axis.client.Stub) {
            ((org.apache.axis.client.Stub)stub).setTimeout(timeout);
        }
    }

    /**
     * Sets on option on the stub to close the connection
     * after receiving the reply (connection will not
     * be reused).
     *
     * @param stub The stub to set the property on
     * @param close If true, connection close will be requested. Otherwise
     *              connection close will not be requested.
     */
    public static void setCloseConnection(Stub stub, boolean close) {
        Hashtable headers = getRequestHeaders(stub);
        if (close) {
            headers.put(HTTPConstants.HEADER_CONNECTION,
                        HTTPConstants.HEADER_CONNECTION_CLOSE);
        } else {
            headers.remove(HTTPConstants.HEADER_CONNECTION);
        }
    }
    
    /**
     * Sets on option on the stub to control what HTTP protocol
     * version should be used.
     *
     * @param stub The stub to set the property on
     * @param enable If true, HTTP 1.0 will be used. If false, HTTP 1.1
     *               will be used.
     */
    public static void setHTTP10Version(Stub stub, boolean enable) {
        setHTTPVersion(stub, enable);
    }

    /**
     * Sets on option on the stub to control what HTTP protocol
     * version should be used.
     *
     * @param stub The stub to set the property on
     * @param http10 If true, HTTP 1.0 will be used. Otherwise HTTP 1.1
     *               will be used.
     */
    public static void setHTTPVersion(Stub stub, boolean http10) {
        stub._setProperty(MessageContext.HTTP_TRANSPORT_VERSION,
                          (http10) 
                          ? HTTPConstants.HEADER_PROTOCOL_V10 
                          : HTTPConstants.HEADER_PROTOCOL_V11);
    }

    /**
     * Sets on option on the stub to use to enable or disable chunked encoding
     * (only if used with HTTP 1.1).
     *
     * @param stub The stub to set the property on
     * @param enable If true, chunked encoding will be enabled. If false,
     *               chunked encoding will be disabled.
     */
    public static void setChunkedEncoding(Stub stub, boolean enable) {
        setDisableChunking(stub, !enable);
    }

    /**
     * Sets on option on the stub to use to disable chunking
     * (only if used with HTTP 1.1).
     *
     * @param stub The stub to set the property on
     * @param disable If true, chunking will be disabled. Otherwise chunking
     *                will be performed (if HTTP 1.1 will be used).
     */
    public static void setDisableChunking(Stub stub, boolean disable) {
        stub._setProperty(DISABLE_CHUNKING, 
                          (disable) 
                          ? Boolean.TRUE
                          : Boolean.FALSE);
        Hashtable headers = getRequestHeaders(stub);
        headers.put(HTTPConstants.HEADER_TRANSFER_ENCODING_CHUNKED,
                    (disable) ? "false" : "true");
    }

    private static Hashtable getRequestHeaders(Stub stub) {
        Hashtable headers = 
            (Hashtable)stub._getProperty(HTTPConstants.REQUEST_HEADERS);
        if (headers == null) {
            headers = new Hashtable();
            stub._setProperty(HTTPConstants.REQUEST_HEADERS, headers);
        }
        return headers;
    }

}
