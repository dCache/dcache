/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.axis.transport.commons.tests;

import org.apache.commons.httpclient.HostConfiguration;

import org.globus.axis.transport.commons.ExtendedHostConfiguration;

import junit.framework.TestCase;
import junit.framework.Test;
import junit.framework.TestSuite;

public class ExtendedHostConfigurationTest extends TestCase {

    private static final String [] PARAMS = { "A", "B" };
    private static int counter = 0;

    public ExtendedHostConfigurationTest(String name) {
	super(name);
    }

    public static void main (String[] args) {
	junit.textui.TestRunner.run (suite());
    }

    public static Test suite() {
	return new TestSuite(ExtendedHostConfigurationTest.class);
    }

    public void testEqualsAndHashNoExtra() {
        
        HostConfiguration h1 = getHostConfiguration(null);
        HostConfiguration h2 = getHostConfiguration(null);

        assertEquals(h1.hashCode(), h2.hashCode());
        assertTrue(h1.equals(h2));
        assertTrue(h2.equals(h1));

        System.out.println(h1);
    }

    public void testEqualsAndHashSame() {
        
        HostConfiguration h1 = getHostConfiguration(PARAMS);
        HostConfiguration h2 = getHostConfiguration(PARAMS);

        assertEquals(h1.hashCode(), h2.hashCode());
        assertTrue(h1.equals(h2));
        assertTrue(h2.equals(h1));

        System.out.println(h1);
    }

    public void testEqualsAndHashDifferent() {
        
        HostConfiguration h1 = getHostConfiguration(PARAMS, "foo", "B");
        HostConfiguration h2 = getHostConfiguration(PARAMS, "foo", "C");

        assertTrue(h1.hashCode() != h2.hashCode());
        assertTrue(!h1.equals(h2));
        assertTrue(!h2.equals(h1));

        System.out.println(h1);
        System.out.println(h2);
    }

    private HostConfiguration getHostConfiguration(String [] params) {
        return getHostConfiguration(params, "foo", "bar");
    }

    private HostConfiguration getHostConfiguration(String [] params,
                                                   String valueA,
                                                   String valueB) {
        HostConfiguration h1 = new HostConfiguration();
        h1.setHost("foobar", 80);

        ExtendedHostConfiguration eh1 = new ExtendedHostConfiguration(h1,
                                                                      params);
        
        eh1.getParams().setParameter("A", valueA);
        eh1.getParams().setParameter("B", valueB);
        // even if C is different it's not included in the test
        eh1.getParams().setParameter("C", String.valueOf(counter++));
        
        return eh1;
    }

}

