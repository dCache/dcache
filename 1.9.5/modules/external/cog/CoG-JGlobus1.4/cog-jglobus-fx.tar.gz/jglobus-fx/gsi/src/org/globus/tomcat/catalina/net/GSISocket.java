/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tomcat.catalina.net;

import org.globus.common.ChainedIOException;
import org.globus.gsi.gssapi.auth.AuthorizationException;
import org.globus.security.gridmap.GridMap;
import org.ietf.jgss.GSSContext;
import org.ietf.jgss.GSSCredential;
import org.ietf.jgss.GSSException;

import java.io.IOException;
import java.net.Socket;

public class GSISocket extends HTTPSSocket {

    protected GridMap gridMap;

    protected GSSCredential delegatedCreds;
    protected String userID;

    private boolean init = false;

    public GSISocket(Socket socket, GSSContext context) {
        super(socket, context);
    }

    public void setGridMap(GridMap gridMap) {
        this.gridMap = gridMap;
    }

    public GSSCredential getDelegatedCredentials() {
        return delegatedCreds;
    }

    public String getAuthorizedUserName() {
        return userID;
    }

    public String getAuthorizedUserDN() {
        return getUserDN();
    }

    public synchronized void startHandshake()
            throws IOException {
        super.startHandshake();

        if (init) {
            return;
        }

        GSSContext context = getContext();

        try {
            delegatedCreds = context.getDelegCred();
        } catch (GSSException e) {
            throw new ChainedIOException("Failed to retreive context properties", e);
        }

        userID = gridMap.getUserID(userDN);

        if (userID == null) {
            // FIXME: should close socket?
            throw new AuthorizationException("User not authenticated: " +
                    userDN);
        }

        init = true;
    }

}
