/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.axis.transport.commons;

import java.net.URL;

import org.apache.axis.MessageContext;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.protocol.Protocol;

import org.apache.axis.components.net.CommonsHTTPClientProperties;
import org.apache.axis.components.net.CommonsHTTPClientPropertiesFactory;

import org.globus.axis.transport.HTTPUtils;

/**
 * Overwrites the Axis sender to use a global connection manager
 */
public class HTTPSender
    extends org.apache.axis.transport.http.CommonsHTTPSender {

    private static CommonsHttpConnectionManager globalConnectionManager;
    private static CommonsHTTPClientProperties globalClientProperties;

    static {
        // install protocol handler
        Protocol protocol = 
            new Protocol("http", new CommonsSocketFactory(), 80);
        Protocol.registerProtocol("http", protocol);

        // initialize connection manager
        globalConnectionManager = new CommonsHttpConnectionManager(null);
        globalClientProperties = CommonsHTTPClientPropertiesFactory.create();
        CommonsHttpConnectionManager.setStaleCheckingEnabled(
                                              globalConnectionManager);
        CommonsHttpConnectionManager.setConnectionIdleTime(
                                              globalConnectionManager);
    }

    protected void initialize() {
        this.clientProperties = globalClientProperties;
        this.connectionManager = globalConnectionManager;
    }

    protected HostConfiguration getHostConfiguration(HttpClient client, 
                                                     MessageContext context,
                                                     URL targetURL) {
        HostConfiguration hc = super.getHostConfiguration(client, context, targetURL);

        // handle disable chunking option
        Boolean prop = (Boolean)context.getProperty(HTTPUtils.DISABLE_CHUNKING);
        if (prop != null) {
            client.getParams().setParameter(HTTPUtils.DISABLE_CHUNKING, prop);
        }
        return hc;
    }
    
}
