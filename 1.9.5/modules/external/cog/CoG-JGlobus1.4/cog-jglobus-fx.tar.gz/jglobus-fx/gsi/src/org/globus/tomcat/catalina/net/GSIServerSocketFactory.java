/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tomcat.catalina.net;

import org.globus.security.gridmap.GridMap;

import org.gridforum.jgss.ExtendedGSSContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Extends HTTPSServerSocketFactory with gridmap authorization
 * and defaults to GSI authentication (SSL + delegation).
 */
public class GSIServerSocketFactory
    extends HTTPSServerSocketFactory {

    private String gridMapFile = "/etc/grid-security/grid-mapfile";

    private static Log logger =
        LogFactory.getLog(GSIServerSocketFactory.class);

    public GSIServerSocketFactory() {
        setCert("/etc/grid-security/hostcert.pem");
        setKey("/etc/grid-security/hostkey.pem");
        setCacertdir("/etc/grid-security/certificates");
        setMode(HTTPSServerSocketFactory.MODE_GSI);
    }

    public void setGridMap(String file) {
        this.gridMapFile = file;
    }

    public String getGridMap() {
        return gridMapFile;
    }

    // ------------------------------------------

    /**
     * Creates a secure server socket on a specified port with default
     * user credentials. A port of <code>0</code> creates a socket on
     * any free port or if the tcp.port.range system property is set
     * it creates a socket within the specified port range.
     * <p/>
     * The maximum queue length for incoming connection indications (a
     * request to connect) is set to the <code>backlog</code> parameter. If
     * a connection indication arrives when the queue is full, the
     * connection is refused.
     *
     * @param port     the port number, or <code>0</code> to use any
     *                 free port or if the tcp.port.range property set
     *                 to use any available port within the specified port
     *                 range.
     * @param backlog  the maximum length of the queue.
     * @param bindAddr the local InetAddress the server will bind to.
     * @throws IOException if an I/O error occurs when opening the socket.
     */
    public ServerSocket createSocket(int port,
                                     int backlog,
                                     InetAddress bindAddr)
            throws IOException {

        GridMap gridMap = new GridMap();

        if (logger.isInfoEnabled()) {
            logger.info("Loading gridmap file:" + gridMapFile);
        }

        gridMap.load(gridMapFile);

        GSIServerSocket serverSocket = (GSIServerSocket)
                super.createSocket(port, backlog, bindAddr);

        serverSocket.setGridMap(gridMap);

        return serverSocket;
    }

    protected HTTPSServerSocket createServerSocket(
            int port, int backlog, InetAddress bindAddr)
            throws IOException {
        return new GSIServerSocket(port, backlog, bindAddr);
    }

    class GSIServerSocket extends HTTPSServerSocket {

        private GridMap _gridMap;

        public GSIServerSocket(int port, int backlog,
                               InetAddress bindAddr)
                throws IOException {
            super(port, backlog, bindAddr);
        }

        public void setGridMap(GridMap gridMap) {
            this._gridMap = gridMap;
        }

        public Socket accept()
                throws IOException {

            GSISocket s = (GSISocket) super.accept();

            // refresh grid map
            this._gridMap.refresh();

            // set grid map
            s.setGridMap(this._gridMap);

            return s;
        }

        protected Socket createSocket(Socket s, ExtendedGSSContext context) {
            return new GSISocket(s, context);
        }
    }

}
