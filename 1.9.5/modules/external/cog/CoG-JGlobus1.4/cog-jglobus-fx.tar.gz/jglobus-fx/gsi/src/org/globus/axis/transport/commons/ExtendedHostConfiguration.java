/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.axis.transport.commons;

import org.apache.commons.httpclient.HostConfiguration;

public class ExtendedHostConfiguration extends HostConfiguration {
        
    private String [] paramList;
    
    public ExtendedHostConfiguration(ExtendedHostConfiguration host) {
        super(host);
    }

    public ExtendedHostConfiguration(HostConfiguration host,
                                     String [] paramList) {
        super(host);
        this.paramList = paramList;
    }

    public boolean equals(Object o) {
        if (o instanceof ExtendedHostConfiguration) {
            if (!super.equals(o)) {
                return false;
            }
            // check params if any
            if (this.paramList != null) {
                ExtendedHostConfiguration other = (ExtendedHostConfiguration)o;
                for (int i=0;i<this.paramList.length;i++) {
                    Object o1 = getParameter(this.paramList[i]);
                    Object o2 = other.getParameter(this.paramList[i]);
                    if (o1 == null) {
                        if (o2 == null) {
                            // they are the same - continue
                        } else {
                            return false;
                        }
                    } else {
                        if (o1.equals(o2)) {
                            // they are the same - continue
                        } else {
                            return false;
                        }
                    }
                }
            }
            
            return true;
        } else {
            return false;
        }
    }
    
    public int hashCode() {
        int hash = super.hashCode();
        if (this.paramList == null) {
            return hash;
        } else {
            for (int i=0;i<this.paramList.length;i++) {
                Object value = getParameter(this.paramList[i]);
                if (value != null) {
                    hash += (this.paramList[i].hashCode() ^ value.hashCode());
                }
            }
            return hash;
        }
    }

    public String toString() {
        String hp = super.toString();
        if (this.paramList == null) {
            return hp;
        } else {
            StringBuffer buf = new StringBuffer();
            buf.append(hp).append("\r\n");
            for (int i=0;i<this.paramList.length;i++) {
                Object value = getParameter(this.paramList[i]);
                if (value != null) {
                    buf.append(this.paramList[i]).append('=');
                    buf.append(value).append(' ');
                }
            }
            return buf.toString();
        }
    }
    
    private Object getParameter(String key) {
        return getParams().getParameter(key);
    }
    
    public Object clone() {
        return new ExtendedHostConfiguration(this);
    }    
}
