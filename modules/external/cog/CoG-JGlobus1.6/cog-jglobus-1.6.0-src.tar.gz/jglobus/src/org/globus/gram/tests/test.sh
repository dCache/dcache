#! /bin/sh


echo test 1 2 3
echo test 4 5 6

sleep 10

echo test 7 8 9
echo "test 10 11 12" 1>&2
