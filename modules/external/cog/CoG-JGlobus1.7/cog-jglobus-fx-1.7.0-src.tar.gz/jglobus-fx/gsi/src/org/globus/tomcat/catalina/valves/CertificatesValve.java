/*
 * Copyright 1999-2006 University of Chicago
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.globus.tomcat.catalina.valves;

import java.io.IOException;
import javax.servlet.ServletException;
import org.apache.catalina.Context;
import org.apache.catalina.Lifecycle;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.LifecycleListener;
import org.apache.catalina.Logger;
import org.apache.catalina.Request;
import org.apache.catalina.Response;
import org.apache.catalina.ValveContext;
import org.apache.catalina.deploy.LoginConfig;
import org.apache.catalina.util.LifecycleSupport;
import org.apache.catalina.util.StringManager;
import org.apache.catalina.valves.ValveBase;
import org.apache.catalina.valves.Constants;

import org.globus.tomcat.catalina.net.GSISocket;
import org.globus.axis.gsi.GSIConstants;

public final class CertificatesValve
    extends ValveBase implements Lifecycle {

    // ----------------------------------------------------- Instance Variables

    /**
     * Are certificates required for authentication by this web application?
     */
    protected boolean certificates = false;


    /**
     * The debugging detail level for this component.
     */
    protected int debug = 0;


    /**
     * The descriptive information related to this implementation.
     */
    protected static final String info =
        "org.globus.tomcat.catalina.valves.CertificatesValve/1.0";


    /**
     * The lifecycle event support for this component.
     */
    protected LifecycleSupport lifecycle = new LifecycleSupport(this);


    /**
     * The StringManager for this package.
     */
    protected static StringManager sm =
        StringManager.getManager(Constants.Package);


    /**
     * Has this component been started yet?
     */
    protected boolean started = false;


    // ------------------------------------------------------------- Properties


    /**
     * Return the debugging detail level for this component.
     */
    public int getDebug() {

        return (this.debug);

    }


    /**
     * Set the debugging detail level for this component.
     */
    public void setDebug(int debug) {

        this.debug = debug;

    }


    /**
     * Return descriptive information about this Valve implementation.
     */
    public String getInfo() {

        return (info);

    }


    // --------------------------------------------------------- Public Methods


    /**
     * Expose the certificates chain if one was included on this request.
     *
     * @param request The servlet request to be processed
     * @param response The servlet response to be created
     * @param context The valve context used to invoke the next valve
     *  in the current processing pipeline
     *
     * @exception IOException if an input/output error occurs
     * @exception ServletException if a servlet error occurs
     */
    public void invoke(Request request, Response response,
                       ValveContext context)
        throws IOException, ServletException {

        // Identify the underlying request if this request was wrapped
        Request actual = request;
        //RequestWrapper is deprecated
        //while (actual instanceof RequestWrapper)
        //    actual = ((RequestWrapper) actual).getWrappedRequest();
        //        if (debug >= 2)
        //            log("Processing request");

        // Verify the existence of a certificate chain if appropriate
        if (certificates)
            verify(request, actual);

        // Expose the certificate chain if appropriate
        expose(request, actual);

        // Invoke the next Valve in our Pipeline
        context.invokeNext(request, response);

    }


    // ------------------------------------------------------ Lifecycle Methods


    /**
     * Add a LifecycleEvent listener to this component.
     *
     * @param listener The listener to add
     */
    public void addLifecycleListener(LifecycleListener listener) {
        lifecycle.addLifecycleListener(listener);
    }


    /**
     * Remove a LifecycleEvent listener from this component.
     *
     * @param listener The listener to remove
     */
    public void removeLifecycleListener(LifecycleListener listener) {
        lifecycle.removeLifecycleListener(listener);
    }

    public LifecycleListener[] findLifecycleListeners() {
	return new LifecycleListener[] {};
    }


    /**
     * Prepare for the beginning of active use of the public methods of this
     * component.  This method should be called before any of the public
     * methods of this component are utilized.  It should also send a
     * LifecycleEvent of type START_EVENT to any registered listeners.
     *
     * @exception IllegalStateException if this component has already been
     *  started
     * @exception LifecycleException if this component detects a fatal error
     *  that prevents this component from being used
     */
    public void start() throws LifecycleException {

        // Validate and update our current component state
        if (started)
            throw new LifecycleException
                (sm.getString("certificatesValve.alreadyStarted"));
        started = true;
        if (debug >= 1)
            log("Starting");

        // Check what type of authentication (if any) we are doing
        certificates = false;
        if (container instanceof Context) {
            Context context = (Context) container;
            LoginConfig loginConfig = context.getLoginConfig();
            if (loginConfig != null) {
                String authMethod = loginConfig.getAuthMethod();
                if ("CLIENT-CERT".equalsIgnoreCase(authMethod))
                    certificates = true;
            }
        }

        // Notify our interested LifecycleListeners
        lifecycle.fireLifecycleEvent(Lifecycle.START_EVENT, null);

    }


    /**
     * Gracefully terminate the active use of the public methods of this
     * component.  This method should be the last one called on a given
     * instance of this component.  It should also send a LifecycleEvent
     * of type STOP_EVENT to any registered listeners.
     *
     * @exception IllegalStateException if this component has not been started
     * @exception LifecycleException if this component detects a fatal error
     *  that needs to be reported
     */
    public void stop() throws LifecycleException {

        // Validate and update our current component state
        if (!started)
            throw new LifecycleException
                (sm.getString("certificatesValve.notStarted"));
        lifecycle.fireLifecycleEvent(Lifecycle.STOP_EVENT, null);
        started = false;
        if (debug >= 1)
            log("Stopping");

        certificates = false;

    }


    // ------------------------------------------------------ Protected Methods


    /**
     * Expose the certificate chain for this request, if there is one.
     *
     * @param request The possibly wrapped Request being processed
     * @param actual The actual underlying Request object
     */
    protected void expose(Request request, Request actual) {

        // Ensure that this request came in on an SSLSocket
        if (actual.getSocket() == null)
            return;
        if (!(actual.getSocket() instanceof GSISocket))
            return;

	if (debug >= 2) {
	    log(" expose: It's a GSI socket");
	}

        GSISocket socket = (GSISocket) actual.getSocket();

	Object tmp = null;

	tmp = socket.getDelegatedCredentials();
	if (tmp != null) {
	    request.getRequest().setAttribute(GSIConstants.GSI_CREDENTIALS,
					      tmp);
	}

	tmp = socket.getAuthorizedUserName();
	if (tmp != null) {
	    request.getRequest().setAttribute(GSIConstants.GSI_AUTH_USERNAME,
                                              tmp);
	}

	tmp = socket.getAuthorizedUserDN();
	if (tmp != null) {
	    request.getRequest().setAttribute(GSIConstants.GSI_USER_DN,
                                              tmp);
	}

	// These are not supported anymore

	/*
	tmp = socket.getPeerCertificateChain();
	if (tmp != null) {
	    request.getRequest().setAttribute(Globals.CERTIFICATES_ATTR,
                                              tmp);
	}

	tmp = socket.getCipherSuite();
	if (tmp != null) {
	    request.getRequest().setAttribute(Globals.CIPHER_SUITE_ATTR,
					      tmp);
	}
	*/
    }

    /**
     * Log a message on the Logger associated with our Container (if any).
     *
     * @param message Message to be logged
     */
    protected void log(String message) {
	if (container != null && container.getLogger() != null) {
	    Logger logger = container.getLogger();
            logger.log("CertificatesValve[" + container.getName() + "]: " +
                       message);
	} else {
            System.out.println("CertificatesValve: " + message);
	}
    }

    /**
     * Log a message on the Logger associated with our Container (if any).
     *
     * @param message Message to be logged
     * @param throwable Associated exception
     */
    protected void log(String message, Throwable throwable) {
	if (container != null && container.getLogger() != null) {
	    Logger logger = container.getLogger();
            logger.log("CertificatesValve[" + container.getName() + "]: " +
                       message, throwable);
        } else {
            System.out.println("CertificatesValve: " + message);
            throwable.printStackTrace(System.out);
        }
    }

    /**
     * Verify that a client certificate chain exists if our web application
     * is doing client certificate authentication.
     *
     * @param request The possibly wrapped Request being processed
     * @param actual The actual underlying Request object
     */
    protected void verify(Request request, Request actual) {
    }


}

