/*
 * Copyright 1999-2006 University of Chicago
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.coyote.http11;

import org.apache.commons.modeler.Registry;
import org.apache.coyote.Request;
import org.apache.tomcat.util.net.TcpConnection;

public class HTTPSProtocol extends Http11Protocol {

    private HttpsConnectionHandler cHandler;

    public HTTPSProtocol() {
        super();
        this.socketFactoryName = "org.globus.tomcat.catalina.net.HTTPSServerSocketFactory";
        this.cHandler = new HttpsConnectionHandler(this);
    }

    public void init() throws Exception {
        super.init();
        ep.setConnectionHandler(this.cHandler);
    }

    public void start() throws Exception {
        super.start();
        if( this.domain != null ) {
            Registry.getRegistry(null, null).registerComponent
                    ( this.cHandler.global, rgOname, null );
        }
    }

    static class HttpsConnectionHandler extends Http11ConnectionHandler {
        public HttpsConnectionHandler(Http11Protocol proto) {
            super(proto);
        }

        public void processConnection(TcpConnection connection, Object thData[]) {
            Http11Processor  processor=null;
            processor = (Http11Processor)thData[Http11Protocol.THREAD_DATA_PROCESSOR];
            Request request = processor.getRequest();
            request.setAttribute("SOCKET", connection.getSocket());
            super.processConnection(connection, thData);
        }
    }

}
