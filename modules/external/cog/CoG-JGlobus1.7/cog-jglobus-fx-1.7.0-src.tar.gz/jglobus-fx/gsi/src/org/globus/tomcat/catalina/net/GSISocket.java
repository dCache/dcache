/*
 * Copyright 1999-2006 University of Chicago
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.globus.tomcat.catalina.net;

import org.globus.common.ChainedIOException;
import org.globus.gsi.gssapi.auth.AuthorizationException;
import org.globus.security.gridmap.GridMap;
import org.ietf.jgss.GSSContext;
import org.ietf.jgss.GSSCredential;
import org.ietf.jgss.GSSException;

import java.io.IOException;
import java.net.Socket;

public class GSISocket extends HTTPSSocket {

    protected GridMap gridMap;

    protected GSSCredential delegatedCreds;
    protected String userID;

    private boolean init = false;

    public GSISocket(Socket socket, GSSContext context) {
        super(socket, context);
    }

    public void setGridMap(GridMap gridMap) {
        this.gridMap = gridMap;
    }

    public GSSCredential getDelegatedCredentials() {
        return delegatedCreds;
    }

    public String getAuthorizedUserName() {
        return userID;
    }

    public String getAuthorizedUserDN() {
        return getUserDN();
    }

    public synchronized void startHandshake()
            throws IOException {
        super.startHandshake();

        if (init) {
            return;
        }

        GSSContext context = getContext();

        try {
            delegatedCreds = context.getDelegCred();
        } catch (GSSException e) {
            throw new ChainedIOException("Failed to retreive context properties", e);
        }

        userID = gridMap.getUserID(userDN);

        if (userID == null) {
            // FIXME: should close socket?
            throw new AuthorizationException("User not authenticated: " +
                    userDN);
        }

        init = true;
    }

}
