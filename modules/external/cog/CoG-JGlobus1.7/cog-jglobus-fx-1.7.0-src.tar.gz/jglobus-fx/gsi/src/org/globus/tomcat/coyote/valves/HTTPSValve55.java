/*
 * Copyright 1999-2006 University of Chicago
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.globus.tomcat.coyote.valves;

import java.io.IOException;

import javax.servlet.ServletException;

import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.Response;

import org.apache.catalina.valves.ValveBase;

import org.ietf.jgss.GSSContext;

import org.globus.tomcat.catalina.net.HTTPSSocket;
import org.globus.axis.gsi.GSIConstants;

import org.apache.coyote.InputBuffer;
import org.apache.coyote.http11.InternalInputBuffer;

public final class HTTPSValve55 extends ValveBase {

    protected static final String info =
        "org.globus.tomcat.catalina.valves.HTTPSTransportValve/1.0";
    
    public String getInfo() {
        return (info);
    }

    public void invoke(Request request, Response response) 
        throws IOException, ServletException {
        // Expose the security parameters
        expose(request);

        // Invoke the next Valve in our Pipeline
        getNext().invoke(request, response);
    }

    private HTTPSSocket getSocketFromInputStream(
                           org.apache.coyote.Request request) {
        InputBuffer inputBuffer = request.getInputBuffer();
        if (inputBuffer instanceof InternalInputBuffer) {
            InternalInputBuffer internalInputBuffer = (InternalInputBuffer)inputBuffer;
            if (internalInputBuffer.getInputStream() 
                instanceof HTTPSSocket.SocketGSIGssInputStream) {
                HTTPSSocket.SocketGSIGssInputStream in = 
                    (HTTPSSocket.SocketGSIGssInputStream)internalInputBuffer.getInputStream();
                return in.getSocket();
            }
        }
        return null;
    }

    protected void expose(Request request) {
        HTTPSSocket socket = 
            getSocketFromInputStream(request.getCoyoteRequest());
        if (socket != null) {
            // fix scheme name
            request.getCoyoteRequest().scheme().setString("https");
            
            String globusID = socket.getUserDN();
            if (globusID != null) {
                request.getRequest().setAttribute(GSIConstants.GSI_USER_DN,
                                                  globusID);
            }
        
            GSSContext context = socket.getContext();
            request.getRequest().setAttribute(GSIConstants.GSI_CONTEXT, 
                                              context);
        }
    }


}
