#!/bin/bash

###################################################################
# Copyright (c) 2004 PPARC, CERN, on behalf of the EU EGEE project.
#
# Instantiates the configuration templates of this package.
#
# Author: Akos.Frohner@cern.ch
# Author: Joni.Hahkala@cern.ch
#
###################################################################

PACKAGENAME=glite-security-trustmanager
USAGE="$0 [--dryrun] [--silent] [--force] [--bouncycastledir dir] [--log4jdir dir] [install_root [config_values_filename [config_directory]]]"

SILENT_ECHO=echo
BC_DIR="/usr/share/java-ext/bouncycastle-jdk1.5/"
LOG4J_DIR="/usr/share/java/"
FORCE='false'

TEMP=$(getopt -o d -l dryrun -l silent -l force -l bouncycastledir: -l log4jdir: -- "$@")
eval set -- "$TEMP"

while true; do
    case "$1" in
        -d|--dryrun)
            DRYRUN='echo Info:'
            shift
            ;;
        --silent)
	    echo silent
            SILENT_ECHO='set IGNORE_STRING='
            shift
            ;;
        --force)
	    echo force
            FORCE="true"
            shift
            ;;
        --bouncycastledir)
	    BC_DIR=$2
	    echo bc dir $BC_DIR
            shift
	    shift
            break
            ;;
        --log4jdir)
            LOG4J_DIR=$2
	    echo log4j dir LOG4J_DIR
            shift
	    shift
            break
            ;;
        --)
            # end of options
            shift
            break
            ;;
    esac
done

#################################################################
# link a file from dir to dest if it doesn't exist
# or when forced

function condLinkFile {
    file=$1
    searchDir=$2
    destDir=$3
    force=$4
    if [ $force == "true" ] || [ ! -e "$destDir/$file" ]; then
	$DRYRUN ln -sf $searchDir/$file $destDir 
    else
	$SILENT_ECHO "File $destDir/$file exists, skippind the linking. Use --force to force linking"
    fi
}

#################################################################
# link a file from dir or other dir to dest if it doesn't exist
# or when forced

function condLinkFileBack {
    file=$1
    searchDir=$2
    backupDir=$3
    destDir=$4
    force=$5
    if [ -e "$searchDir/$file" ]; then
	condLinkFile $file $searchDir $destDir $force
    else
	$SILENT_ECHO "File $searchDir/$file not installed on system using default from trustmanager."
	condLinkFile $file $backupDir $destDir $force
    fi
}

#################################################################
# installation root directory
if [ "$1" == "" ]; then
    INSTALLROOT='/opt/glite'
    $SILENT_ECHO "Info: using default install root: $INSTALLROOT"
else
    INSTALLROOT=$1
    shift
fi
if [ ! -d "$INSTALLROOT" ]; then
    echo "Error: Please specify the installation root directory!"
    echo " (e.g. /opt/glite)"
    echo $USAGE
    exit 1
fi

#################################################################
# configuration file
if [ "$1" == "" ]; then
    VALUESFILE="$INSTALLROOT/etc/$PACKAGENAME/config.properties"
    $SILENT_ECHO "Info: using default configuration file: $VALUESFILE"
else
    VALUESFILE=$1
    shift
fi
if [ ! -f "$VALUESFILE" ]; then
    echo "Error: Please specify the configuration values file!"
    echo " (e.g. config.properties)"
    echo $VALUESFILE
    echo $USAGE
    exit 1
fi

#################################################################
# configuration directory
if [ "$1" == "" ]; then
    CONFIGDIR="$INSTALLROOT/etc/$PACKAGENAME"
    $SILENT_ECHO "Info: using default configuration directory: $CONFIGDIR"
else
    CONFIGDIR=$1
    shift
fi
if [ ! -d "$CONFIGDIR" ]; then
    echo "Error: Please specify the configuration directory!"
    echo " (e.g. /opt/glite/etc/$PACKAGENAME)"
    echo $USAGE
    exit 1
fi

#################################################################
# Tomcat directory
if [ -r "/etc/tomcat5/tomcat5.conf" ]; then
    source "/etc/tomcat5/tomcat5.conf"
    TCCONFIG_DIR="/etc/tomcat5"
else
    if [ -z "$CATALINA_HOME" ]; then
	echo "Please set the CATALINA_HOME environmental variable!"
	exit 2
    fi
    $SILENT_ECHO "Warning: /etc/tomcat5/tomcat5.conf does not exists -- non default install."
    TCCONFIG_DIR="${CATALINA_HOME}/conf"
fi

SERVERXML="${TCCONFIG_DIR}/server.xml"

if [ ! -f "$SERVERXML" ]; then
    echo "Tomcat server configuraton file does not exists: $SERVERXML"
    exit 2
fi


#################################################################
# parsing the properties file and building a sed script:
#
#  - strip the package name prefix and the dot
#  - escape slashes
#  - turn the equal sign, surrounded with whitespaces, into slash
#  - prefix the line with "s/"
#  - suffix the line with "/g;"
#
sedscript=$(grep "^$PACKAGENAME" $VALUESFILE | sed -e "s/^$PACKAGENAME\.//" | sed -e 's/\//\\\//g; s/[ \t]*=[ \t]*/@\//; s/^/s\/@/; s/$/\/g;/;')
#
# add custom patterns: @INSTALLROOT@ -> $INSTALLROOT
#
sedscript=${sedscript}" "$(echo "INSTALLROOT=$INSTALLROOT" | sed -e 's/\//\\\//g; s/[ \t]*=[ \t]*/@\//; s/^/s\/@/; s/$/\/g;/;')
sedscript=${sedscript}" "$(echo "HOSTNAME="$(hostname -f) | sed -e 's/\//\\\//g; s/[ \t]*=[ \t]*/@\//; s/^/s\/@/; s/$/\/g;/;')
sedscript=${sedscript}" "$(echo "CATALINA_HOME=$CATALINA_HOME" | sed -e 's/\//\\\//g; s/[ \t]*=[ \t]*/@\//; s/^/s\/@/; s/$/\/g;/;')

#################################################################
# template instantiation
TEMPLATEDIR="$INSTALLROOT/share/$PACKAGENAME"
if [ ! -d "$TEMPLATEDIR" ]; then
    echo "Error: template directory does not exist: $TEMPLATEDIR"
    echo $USAGE
    exit 3
fi

for template in $(ls $TEMPLATEDIR/*.template); do
    if [ ! -f "$template" ]; then
        echo "Error: $template file does not exist!"
        exit 3
    fi
    filename=$CONFIGDIR/$(basename $template .template)

    if [ -f "$filename" ]; then
        $SILENT_ECHO "Warning: $filename already exists! Saving old one as $filename.old."
        $DRYRUN mv $filename $filename.old
    fi
    
    # let be paranoid with passwords
    $DRYRUN touch $filename
    $DRYRUN chmod 0600 $filename
    # replace the autogenerated patterns
    $DRYRUN cat $template | sed -e "$sedscript" >$filename
done


#################################################################
# configuration
OLDSERVERXML=$SERVERXML.old-glite
ORIGSERVERXML=$SERVERXML.orig-glite
if [ ! -e $ORIGSERVERXML ]; then
    if [ -e $OLDSERVERXML ]; then
	$DRYRUN cp $OLDSERVERXML $ORIGSERVERXML
    else
	$DRYRUN cp $SERVERXML $ORIGSERVERXML
    fi
fi

#if [ -e $OLDSERVERXML ]; then
#    echo "Error: $OLDSERVERXML already exists, so the server is configured"
#    exit 4
#fi

$DRYRUN cp -p $SERVERXML $OLDSERVERXML
$DRYRUN cp $CONFIGDIR/server.xml $SERVERXML
if [ ! -z "$TOMCAT_USER" ]; then
    $DRYRUN chown $TOMCAT_USER $SERVERXML
fi

condLinkFileBack bcprov.jar $BC_DIR $TEMPLATEDIR $CATALINA_HOME/server/lib/ $FORCE
condLinkFileBack log4j.jar $LOG4J_DIR $TEMPLATEDIR $CATALINA_HOME/server/lib/ $FORCE


JARS2="glite-security-trustmanager.jar glite-security-util-java.jar"
for jar in $JARS2; do
    condLinkFile $jar $INSTALLROOT/share/java/ $CATALINA_HOME/server/lib/ $force
done

log4j="log4j-trustmanager.properties"
if [ ! -e "${TCCONFIG_DIR}/$log4j" ]; then
    $DRYRUN cp $CONFIGDIR/$log4j ${TCCONFIG_DIR}/$log4j
fi

$SILENT_ECHO "Info: you can clean up using the following commands"
$SILENT_ECHO "      mv -f $OLDSERVERXML $SERVERXML"
$SILENT_ECHO "      rm -f $CATALINA_HOME/server/lib/bcprov*.jar"
$SILENT_ECHO "      rm -f $CATALINA_HOME/server/lib/log4j*.jar"
$SILENT_ECHO "      rm -f $TCCONFIG_DIR/$log4j"
$SILENT_ECHO "      rm -f ${CONFIGDIR}/server.xml"

